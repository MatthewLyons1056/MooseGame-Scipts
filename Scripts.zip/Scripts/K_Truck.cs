﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class K_Truck : MonoBehaviour
{
    /*
     * Manages Wheels and displays restart panel on Trigger Enter with calling the switch Game Over function
     */

    /// <summary>
    /// Reference to Rigidbody component attached to this car
    /// </summary>
    [Tooltip("A reference to the Rigidbody componenet attached to this car")]
    Rigidbody rb;

    /// <summary>
    /// Reference to Wheels attached to this car
    /// </summary>
    [Tooltip("A reference to the Wheels attached to this car")]
    Transform[] Wheels = new Transform[8]; // Set size to 8


    /// <summary>
    /// A reference to the game controller
    /// </summary>
    [Tooltip("A reference to the game controller")]
    [SerializeField]
    GameController gameController;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameController>();

        for (int i = 0; i < Wheels.Length; i++)
        {
            Wheels[i] = gameObject.transform.GetChild(i);
            //Debug.Log(Wheels[i] + " Assigned.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {

        if (other.CompareTag("Moose"))
        {
            //Debug.Log("Hit!");
            gameController.SwitchGameOver();
            //Checkout time setting for unity
        }
    }
}
