﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class K_EnemyMovement : MonoBehaviour
{
    public float speed = 30;

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation = new Quaternion(0f,0f,0f,0f);
        transform.Translate(0, -1, 0 * Time.deltaTime * speed);
    }
}
